# AI Tutor App

An AI-powered tutor platform where teachers upload class notes (PDFs) and students can ask questions using a custom GPT-based tutor.